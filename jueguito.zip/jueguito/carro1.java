import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class carro1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class carro1 extends Actor
{
    private int speed;
    
    public carro1(int v){
        
        speed = v;
        Greenfoot.playSound("SONIDO.wav");
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()*1/5;
        int mynewWidth = (int)myImage.getWidth()*1/5;
        myImage.scale(mynewWidth, myNewHeight);
    }
    
    
    /**
     * Act - do whatever the carro1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        
        
        if(Greenfoot.isKeyDown("right")){
            if(getX() < 460)
                setLocation(getX() + speed, getY());
        }
        if(Greenfoot.isKeyDown("left")){
            if(getX() > 140)
                setLocation(getX() - speed, getY()); 
        }
        if(Greenfoot.isKeyDown("up")){
            if(getY() > 300)
                setLocation(getX() , getY() - speed); 
        }
        if(Greenfoot.isKeyDown("down")){
            if(getY() < 640)
                setLocation(getX() , getY() + speed); 
        }
        
        checkCollision();
    }
    
    public void checkCollision(){
        Actor collided = getOneIntersectingObject(roca.class);
        if (collided != null)
        {
          getWorld().removeObject(collided);
          getWorld().removeObject(this);
          Greenfoot.stop();
        }
    }
    
    public void aumenta_velocidad(){
        speed++;
    }
}
